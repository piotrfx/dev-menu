<?php

return [
    'failed'   => 'Te poświadczenia nie pasują do naszych danych.',
    'throttle' => 'Zbyt wiele prób logowania. Spróbuj ponownie za :seconds sekundy.',
];
