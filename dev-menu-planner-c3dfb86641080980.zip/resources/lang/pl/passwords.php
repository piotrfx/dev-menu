<?php

return [
    'password' => 'Hasła muszą mieć co najmniej sześć znaków i być zgodne z potwierdzeniem.',
    'reset'    => 'Twoje hasło zostało zresetowane!',
    'sent'     => 'Wysłaliśmy e-mailem link do resetowania hasła!',
    'token'    => 'Ten token resetowania hasła jest nieprawidłowy.',
    'user'     => 'Nie możemy znaleźć użytkownika z tym adresem e-mail.',
    'updated'  => 'Twoje hasło zostało zmienione',
];
