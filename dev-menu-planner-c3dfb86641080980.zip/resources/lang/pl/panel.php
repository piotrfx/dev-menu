<?php

return [
    'site_title' => 'Menu Planner',
];
