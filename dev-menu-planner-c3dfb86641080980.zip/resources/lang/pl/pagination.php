<?php

return [
    'previous' => 'Wstecz',
    'next'     => 'Następna',
];
